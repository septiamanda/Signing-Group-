const express = require('express')
const mysql = require('mysql2')
const expressLayouts = require('express-ejs-layouts')
const path = require('path')
const app = express()

    app.set('views',__dirname)
    app.set('views', path.join(__dirname, '/views'));
    //biar bisa pakai kodingan format ejs(yg % itu lohh)
    app.set('view engine', 'ejs')
    //biar bisa pake css,img dan js
    app.use('/css', express.static(path.resolve(__dirname, "assets/css")));
    // app.use('/js', express.static(path.resolve(__dirname, "assets/js")));
    app.use('/img', express.static(path.resolve(__dirname, "assets/img")));

   

   //biar bisa bikin layout
   app.use(expressLayouts);

//koneksi database
// const db = mysql.createConnection({
//     host: 'localhost',
//     user: 'root',
//     database: 'tb_pweb'
//   });

//   db.connect((err)=>{
//     if(err) throw err
//    console.log('Database terkoneksi!')
//   //  const sql = "SELECT * FROM users";
//   //     db.query(sql,(err,result)=>{
//   //       console.log(result)
//   //     })
//    })

    

   app.get('/register', function (req, res) {
    res.render('register',{
      title : 'Register',
      layout : 'layouts/autentikasi-layout'
    });
})

   app.get('/login', function (req, res) {
    res.render('login',{
      title : 'Login',
      layout : 'layouts/autentikasi-layout'
    });
})

   app.get('/', function (req, res) {
    res.render('index',{ 
    title:"Dashboard", 
    layout:"layouts/main"
  }) 
})

  app.get('/profil', function (req, res) {
      res.render('profil',{ 
      title:"profil",
      layout:"layouts/main"
      }) 
  })
  
  app.get('/add-document', function (req, res) {
      res.render('add-document',{ 
      title:"add document",
      layout:"layouts/main"
      }) 
  })
  app.get('/MoU', function (req, res) {
      res.render('MoU',{ 
      title:"MoU",
      layout:false
      }) 
  })

  app.get('/signature', function (req, res) {
    res.render('signature',{ 
    title:"signature",
    layout:"layouts/main"
    }) 
})

  app.get('/action-req', function (req, res) {
    res.render('action-req',{ 
    title:"action required",
    layout:"layouts/main"
    }) 
})
  app.get('/waiting-others', function (req, res) {
    res.render('waiting-others',{ 
    title:"Waiting others",
    layout:"layouts/main"
    }) 
})
  app.get('/expiring-soon', function (req, res) {
    res.render('expiring-soon',{ 
    title:"Expiring soong",
    layout:"layouts/main"
    }) 
})
  app.get('/completed', function (req, res) {
    res.render('completed',{ 
    title:"Completed",
    layout:"layouts/main"
    }) 
})



app.listen(3000,()=>{
    console.log("Listening at port 3000")
  })